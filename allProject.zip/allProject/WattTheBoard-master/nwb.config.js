module.exports = {
  // Let nwb know this is a React app when generic build commands are used
  type: 'react-app'
}
