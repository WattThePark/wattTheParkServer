var idMachine = 2;
var port = "4000"
var ip = "172.20.10.4";
